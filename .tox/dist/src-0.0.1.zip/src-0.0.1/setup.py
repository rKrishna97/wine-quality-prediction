from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description="It's a wine quality package",
    author="Krishna",
    packages=find_packages(),
    license="MIT"
)